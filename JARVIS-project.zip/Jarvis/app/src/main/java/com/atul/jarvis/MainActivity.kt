package com.atul.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    companion object {
        const val EXTRA_LISTEN = "listen"
        private val CYAN = Color.parseColor("#00E5FF")
        private val BG = Color.parseColor("#05080F")
    }

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private lateinit var engine: CommandEngine
    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var micButton: Button

    private val handler = Handler(Looper.getMainLooper())
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()
    private var listenWhenReady = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = CommandEngine(this)
        buildUi()
        listenWhenReady = wantsListen(intent)
        tts = TextToSpeech(this, this)
        askPermissions(false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (wantsListen(intent)) {
            if (ttsReady) greetAndListen() else listenWhenReady = true
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    private fun wantsListen(i: Intent?): Boolean =
        i != null && (i.getBooleanExtra(EXTRA_LISTEN, false) ||
                i.action == Intent.ACTION_ASSIST ||
                i.action == Intent.ACTION_VOICE_COMMAND)

    // ---------------------------------------------------------------- voice output

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale("en", "IN"))
            tts.setPitch(0.9f)
            tts.setSpeechRate(1.0f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == null) return
                    val cb = callbacks.remove(utteranceId) ?: return
                    handler.post { cb() }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onDone(utteranceId)
                }
            })
            ttsReady = true
        } else {
            addLog("Text-to-speech start nahi hua. Settings > Text-to-speech me Google engine check karo.")
        }

        if (listenWhenReady) {
            listenWhenReady = false
            greetAndListen()
        }
    }

    private fun speak(text: String, then: (() -> Unit)? = null) {
        addLog("JARVIS: $text")
        if (!ttsReady) {
            if (then != null) handler.post { then() }
            return
        }
        val id = UUID.randomUUID().toString()
        if (then != null) callbacks[id] = then
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun greetAndListen() {
        speak("Yes boss?") { startListening() }
    }

    // ---------------------------------------------------------------- voice input

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            addLog("Mic ki permission chahiye.")
            askPermissions(true)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Is phone par speech recognition available nahi hai.")
            return
        }

        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusView.text = "🎧 Sun raha hoon..."
                micButton.alpha = 0.6f
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                statusView.text = "Samajh raha hoon..."
            }

            override fun onError(error: Int) {
                resetStatus()
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> speak("Kuch suna nahi, boss.")
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        addLog("Internet nahi hai. Offline ke liye: Settings > Google > Voice > Offline speech recognition me English (India) download karo.")
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> askPermissions(true)
                    else -> addLog("Sunne me error aaya (code $error). Dobara try karo.")
                }
            }

            override fun onResults(results: Bundle?) {
                resetStatus()
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                handleCommand(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        r.startListening(i)
    }

    private fun resetStatus() {
        statusView.text = "Button dabao aur bolo"
        micButton.alpha = 1f
    }

    // ---------------------------------------------------------------- brain

    private fun handleCommand(text: String) {
        addLog("Aap: $text")
        val result = try {
            engine.execute(text)
        } catch (e: Exception) {
            CommandResult("Kuch gadbad ho gayi: ${e.message}")
        }

        if (result.background) {
            // Screen-control commands: pehle JARVIS peeche jaye, phir doosri app par kaam ho
            speak(result.reply)
            moveTaskToBack(true)
            handler.postDelayed({
                try {
                    result.action?.invoke()
                } catch (e: Exception) {
                    addLog("Action fail: ${e.message}")
                }
            }, 800)
        } else {
            try {
                result.action?.invoke()
            } catch (e: Exception) {
                addLog("Action fail: ${e.message}")
            }
            speak(result.reply)
        }
    }

    // ---------------------------------------------------------------- setup helpers

    private fun askPermissions(fromButton: Boolean) {
        val needed = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

        if (needed.isNotEmpty()) {
            requestPermissions(needed.toTypedArray(), 1)
        } else if (fromButton) {
            addLog("✅ Saari permissions mil chuki hain.")
        }
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            addLog("Ye settings page nahi khul paya.")
        }
    }

    private fun addLog(line: String) {
        logView.append("$line\n\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    // ---------------------------------------------------------------- UI

    private fun makeSetupButton(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 13f
        b.setTextColor(CYAN)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(10).toFloat()
        bg.setColor(Color.TRANSPARENT)
        bg.setStroke(dp(1), CYAN)
        b.background = bg
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setBackgroundColor(BG)
        root.setPadding(dp(20), dp(36), dp(20), dp(20))

        val title = TextView(this)
        title.text = "J.A.R.V.I.S"
        title.textSize = 34f
        title.letterSpacing = 0.15f
        title.setTextColor(CYAN)
        title.typeface = Typeface.create("sans-serif-light", Typeface.BOLD)
        title.gravity = Gravity.CENTER

        statusView = TextView(this)
        statusView.textSize = 15f
        statusView.setTextColor(Color.parseColor("#9FB3C8"))
        statusView.gravity = Gravity.CENTER
        statusView.setPadding(0, dp(8), 0, dp(20))

        micButton = Button(this)
        micButton.text = "🎙\nBOLO"
        micButton.textSize = 22f
        micButton.typeface = Typeface.DEFAULT_BOLD
        micButton.setTextColor(BG)
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(CYAN)
        circle.setStroke(dp(6), Color.parseColor("#0091A8"))
        micButton.background = circle
        micButton.layoutParams = LinearLayout.LayoutParams(dp(180), dp(180))
        micButton.setOnClickListener { startListening() }

        scroll = ScrollView(this)
        val scrollLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        scrollLp.topMargin = dp(20)
        scroll.layoutParams = scrollLp
        logView = TextView(this)
        logView.textSize = 14f
        logView.setTextColor(Color.parseColor("#D7E3F0"))
        scroll.addView(logView)

        root.addView(title)
        root.addView(statusView)
        root.addView(micButton)
        root.addView(scroll)
        root.addView(makeSetupButton("1. Permissions do (mic, contacts, call)") { askPermissions(true) })
        root.addView(makeSetupButton("2. Accessibility on karo (screen control)") {
            openSettings(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(makeSetupButton("3. App info (battery Unrestricted / restricted settings allow)") {
            openSettings(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })

        setContentView(root)
        resetStatus()
        addLog(
            "JARVIS online.\n\nTry karo:\n" +
                    "• torch on karo / torch band karo\n" +
                    "• battery kitni hai / time kya hai\n" +
                    "• youtube kholo / youtube par shiv bhajan\n" +
                    "• mummy ko call karo\n" +
                    "• rahul ko whatsapp karo ki main late aaunga\n" +
                    "• alarm 6 baje / alarm 9:30 raat\n" +
                    "• volume badhao / silent karo\n" +
                    "• scroll down / back / home / screenshot\n" +
                    "• subscribe par click karo"
        )
    }
}
