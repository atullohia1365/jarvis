package com.atul.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Screen control: click, type, scroll, back, home, etc.
 * User ko Settings > Accessibility me "JARVIS screen control" on karna hota hai.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Abhi events ki zaroorat nahi, sirf commands par kaam karte hain.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /** Screen par diye gaye text (ya content description) wale element par click. */
    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(text)
        for (found in nodes) {
            var node: AccessibilityNodeInfo? = found
            while (node != null && !node.isClickable) {
                node = node.parent
            }
            if (node != null && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true
            }
        }
        return false
    }

    /** Focused text box (ya pehle editable box) me text likhna. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val hit = findEditable(child)
            if (hit != null) return hit
        }
        return null
    }

    /** fingerUp = true -> ungli upar khiskao (content neeche scroll hota hai). */
    fun swipe(fingerUp: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val yStart = dm.heightPixels * (if (fingerUp) 0.75f else 0.30f)
        val yEnd = dm.heightPixels * (if (fingerUp) 0.30f else 0.75f)
        val path = Path()
        path.moveTo(x, yStart)
        path.lineTo(x, yEnd)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 350L))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
