package com.atul.jarvis

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * reply      = JARVIS kya bolega
 * background = true ho toh JARVIS pehle khud peeche jayega, phir action karega
 *              (screen control wale commands ke liye, taaki doosri app par kaam ho)
 * action     = baad me chalne wala kaam
 */
data class CommandResult(
    val reply: String,
    val background: Boolean = false,
    val action: (() -> Unit)? = null
)

class CommandEngine(private val ctx: Context) {

    private val appAliases = mapOf(
        "youtube studio" to "yt studio",
        "studio" to "yt studio",
        "insta" to "instagram",
        "fb" to "facebook",
        "setting" to "settings",
        "playstore" to "play store",
        "calculator" to "calculator",
        "gallery" to "photos"
    )

    // ---------------------------------------------------------------- main

    fun execute(raw: String): CommandResult {
        val t = raw.lowercase(Locale.ROOT)
            .replace("jarvis", " ")
            .replace("whats app", "whatsapp")
            .replace("wi-fi", "wifi")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (t.isBlank()) return CommandResult("Kuch suna nahi, boss.")

        // ---- Screen par click / type (Accessibility)
        Regex("^(?:click|tap|press)\\s+(?:on\\s+)?(.+)$").find(t)?.let {
            return click(it.groupValues[1])
        }
        Regex("^(.+?)\\s+(?:par |pe |per )?(?:click karo|click kar do|tap karo|dabao|daba do|press karo)$").find(t)?.let {
            return click(it.groupValues[1])
        }
        Regex("^(?:type|likho|write)\\s+(.+)$").find(t)?.let {
            return type(it.groupValues[1])
        }
        Regex("^(.+?)\\s+(?:type karo|type kar do|likho|likh do)$").find(t)?.let {
            return type(it.groupValues[1])
        }

        // ---- Baatcheet
        if (t in setOf("hi", "hello", "hey", "namaste", "namaskar")) {
            return CommandResult("Hello boss. Main ready hoon.")
        }
        if (t.has("kaise ho", "how are you")) return CommandResult("Main bilkul theek hoon, boss. Aap batao, kya karna hai?")
        if (t.has("kaun ho", "who are you", "your name", "tumhara naam")) {
            return CommandResult("Main JARVIS hoon, aapka personal assistant.")
        }
        if (t.has("thank", "shukriya", "dhanyavad", "dhanyawad")) return CommandResult("Always at your service, boss.")

        // ---- Torch
        if (t.has("torch", "flash")) {
            val off = t.has("off", "band", "bujha", "bandh")
            return torch(!off)
        }

        // ---- Alarm
        if (t.has("alarm", "jaga dena", "utha dena")) return alarm(t)

        // ---- Battery
        if (t.has("battery", "charging", "charge")) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return CommandResult("Battery $p percent hai, boss.")
        }

        // ---- Date / Time
        if (t.has("date", "tarikh", "tareekh", "aaj kya din", "aaj kaun sa din", "which day")) {
            val d = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.US).format(Date())
            return CommandResult("Aaj $d hai.")
        }
        if (t.has("time", "samay", "baje", "baj rahe", "kitna baja")) {
            val now = SimpleDateFormat("h:mm a", Locale.US).format(Date())
            return CommandResult("Abhi $now ho rahe hain, boss.")
        }

        // ---- Ringer mode
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (t.has("normal mode", "ring mode", "general mode", "silent hatao", "silent off", "sound on", "ringer on")) {
            return try {
                am.ringerMode = AudioManager.RINGER_MODE_NORMAL
                CommandResult("Phone normal mode par aa gaya.")
            } catch (e: SecurityException) {
                CommandResult("Ringer mode badalne ki permission nahi mili.")
            }
        }
        if (t.has("silent", "vibrate", "vibration")) {
            return try {
                am.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                CommandResult("Phone vibrate mode par kar diya, boss.")
            } catch (e: SecurityException) {
                CommandResult("Ringer mode badalne ki permission nahi mili.")
            }
        }

        // ---- Volume
        if (t.has("volume", "awaaz", "awaz", "aawaz")) {
            val s = AudioManager.STREAM_MUSIC
            val flag = AudioManager.FLAG_SHOW_UI
            return when {
                t.has("mute") -> {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, flag)
                    CommandResult("Volume mute.")
                }
                t.has("max", "full", "poora", "puri", "pura") -> {
                    am.setStreamVolume(s, am.getStreamMaxVolume(s), flag)
                    CommandResult("Volume full kar diya.")
                }
                t.has("down", "kam", "low", "ghata", "decrease", "dheere", "dheemi") -> {
                    repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, flag) }
                    CommandResult("Volume kam kar diya.")
                }
                else -> {
                    repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, flag) }
                    CommandResult("Volume badha diya.")
                }
            }
        }

        // ---- WiFi / Bluetooth / Settings panels
        if (t.has("wifi", "internet", "mobile data")) {
            return launchResult(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY), "Internet settings khol di.")
        }
        if (t.has("bluetooth")) {
            return launchResult(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), "Bluetooth settings khol di.")
        }

        // ---- App kholna (agar app mil jaye)
        val openTarget = Regex("^(?:open|launch|start|kholo)\\s+(.+)$").find(t)?.groupValues?.get(1)
            ?: Regex("^(.+?)\\s+(?:app\\s+)?(?:kholo|khol do|open karo|open kar do|open|chalao|chala do|start karo|launch karo)$")
                .find(t)?.groupValues?.get(1)
        if (openTarget != null) {
            val pkg = findApp(openTarget)
            if (pkg != null) {
                val launchIntent = ctx.packageManager.getLaunchIntentForPackage(pkg)
                if (launchIntent != null && launch(launchIntent)) {
                    return CommandResult("$openTarget khol raha hoon.")
                }
            }
        }

        // ---- WhatsApp message
        if (t.has("whatsapp")) return whatsapp(t)

        // ---- Call
        if (t.has("call", "phone laga", "phone karo", "phone kar do", "dial")) return call(t)

        // ---- YouTube / gaana
        if (t.has("youtube") || t.startsWith("play ") || t.has(" bajao", "gaana chalao", "song chalao", "gana chalao")) {
            val q = stripWords(
                t, setOf(
                    "youtube", "par", "pe", "per", "on", "play", "chalao", "lagao", "bajao", "search",
                    "karo", "open", "kholo", "me", "mein", "gaana", "gana", "song", "chala", "do"
                )
            )
            return youtube(q)
        }

        // ---- Google search
        if (t.startsWith("search ") || t.startsWith("google ") || t.endsWith(" search karo") || t.endsWith(" google karo")) {
            val q = stripWords(t, setOf("search", "google", "karo", "par", "pe", "on", "for", "kar", "do"))
            val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
            return launchResult(i, "$q search kar raha hoon.")
        }

        if (openTarget != null) {
            return CommandResult("'$openTarget' naam ki app phone me nahi mili, boss.")
        }

        // ---- Navigation (Accessibility)
        if (t.has("screenshot", "screen shot")) {
            return global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Screenshot le raha hoon.")
        }
        if (t.has("scroll down", "neeche", "niche", "nichy")) return gesture(true, "Neeche scroll.")
        if (t.has("scroll up", "upar", "oopar", "uper")) return gesture(false, "Upar scroll.")
        if (t == "back" || t.has("go back", "back jao", "back karo", "peeche", "piche", "wapas")) {
            return global(AccessibilityService.GLOBAL_ACTION_BACK, "Back.")
        }
        if (t == "home" || t.has("home screen", "home jao", "go home", "home par")) {
            return global(AccessibilityService.GLOBAL_ACTION_HOME, "Home screen.")
        }
        if (t.has("recent")) return global(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps.")
        if (t.has("notification")) {
            return global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications khol di.")
        }
        if (t.has("lock")) return global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Phone lock kar raha hoon.")

        return CommandResult("Sorry boss, ye command abhi mujhe nahi aati.")
    }

    // ---------------------------------------------------------------- helpers

    private fun String.has(vararg words: String): Boolean = words.any { this.contains(it) }

    private fun stripWords(t: String, words: Set<String>): String =
        t.split(" ").filter { it.isNotBlank() && it !in words }.joinToString(" ").trim()

    private fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    private fun launchResult(intent: Intent, okReply: String): CommandResult =
        if (launch(intent)) CommandResult(okReply) else CommandResult("Ye kaam nahi ho paya, boss.")

    private fun toast(msg: String) {
        Toast.makeText(ctx.applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------------------------------------------------------------- features

    private fun torch(on: Boolean): CommandResult {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return CommandResult("Is phone me flash nahi mila.")
            cm.setTorchMode(id, on)
            CommandResult(if (on) "Torch on, boss." else "Torch off.")
        } catch (e: Exception) {
            CommandResult("Torch me problem aa gayi.")
        }
    }

    private fun alarm(t: String): CommandResult {
        val m = Regex("(\\d{1,2})(?:[:. ](\\d{2}))?").find(t)
            ?: return launchResult(Intent(AlarmClock.ACTION_SHOW_ALARMS), "Alarm app khol diya. Time bata ke bolo, jaise 'alarm 6 baje'.")
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].toIntOrNull() ?: 0
        val isPm = listOf("pm", "p.m", "p m", "shaam", "sham", "raat", "evening", "night", "dopahar", "afternoon")
            .any { t.contains(it) }
        if (isPm && hour < 12) hour += 12
        if (hour > 23 || minute > 59) return CommandResult("Time samajh nahi aaya, boss.")

        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS alarm")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val ampm = if (hour < 12) "AM" else "PM"
        val shown = String.format(Locale.US, "%d:%02d %s", h12, minute, ampm)
        return launchResult(intent, "Alarm $shown ka set kar diya, boss.")
    }

    private fun findApp(nameRaw: String): String? {
        var name = nameRaw.trim()
            .removePrefix("the ")
            .removeSuffix(" app")
            .trim()
        appAliases[name]?.let { name = it }
        if (name.length < 2) return null

        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map {
            it.loadLabel(pm).toString().lowercase(Locale.ROOT) to it.activityInfo.packageName
        }
        val hit = apps.firstOrNull { it.first == name }
            ?: apps.firstOrNull { it.first.startsWith(name) }
            ?: apps.firstOrNull { it.first.contains(name) }
        return hit?.second
    }

    private fun findContact(name: String): Pair<String, String>? {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val n = name.trim()
        if (n.isEmpty()) return null
        val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        ctx.contentResolver.query(phone, projection, selection, arrayOf("%$n%"), null)?.use { c ->
            if (c.moveToFirst()) {
                val dn = c.getString(0) ?: n
                val num = c.getString(1) ?: return null
                return dn to num
            }
        }
        return null
    }

    private fun call(t: String): CommandResult {
        val name = stripWords(
            t, setOf(
                "call", "karo", "kar", "do", "ko", "lagao", "laga", "phone", "please", "dial",
                "to", "pe", "par", "number", "ek", "ka", "abhi"
            )
        )
        if (name.isBlank()) return CommandResult("Kisko call karun, boss?")

        val digits = name.replace(" ", "")
        val (who, number) = if (digits.isNotEmpty() && digits.all { it.isDigit() || it == '+' }) {
            digits to digits
        } else {
            findContact(name) ?: return if (
                ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED
            ) {
                CommandResult("Contacts ki permission do, boss.")
            } else {
                CommandResult("'$name' naam ka contact nahi mila.")
            }
        }

        val canCall = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val intent = Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
        return launchResult(intent, "$who ko call kar raha hoon.")
    }

    private fun whatsapp(t: String): CommandResult {
        val cmdWords = setOf(
            "whatsapp", "ko", "pe", "par", "per", "message", "msg", "bhejo", "send", "karo",
            "kar", "do", "to", "on", "a", "pr"
        )
        val glueWords = cmdWords + setOf("ki", "ke", "that", "bolo", "likho", "saying")
        val tokens = t.split(" ").filter { it.isNotBlank() }

        var i = 0
        while (i < tokens.size && tokens[i] in cmdWords) i++

        // Pehle 2 shabd, phir 1 shabd ko contact naam maan ke dhoondo
        var contact: Pair<String, String>? = null
        var used = 0
        for (k in 2 downTo 1) {
            if (i + k > tokens.size) continue
            val candidate = tokens.subList(i, i + k).joinToString(" ")
            val found = findContact(candidate)
            if (found != null) {
                contact = found
                used = k
                break
            }
        }

        if (contact == null) {
            if (tokens.size <= 2) {
                // "whatsapp kholo" jaisa command
                val pkgIntent = ctx.packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (pkgIntent != null && launch(pkgIntent)) return CommandResult("WhatsApp khol diya.")
            }
            return CommandResult("Contact nahi mila, boss. Aise bolo: 'Rahul ko whatsapp karo ki main late aaunga'.")
        }

        var j = i + used
        while (j < tokens.size && tokens[j] in glueWords) j++
        val message = tokens.drop(j).joinToString(" ")

        var digits = contact.second.filter { it.isDigit() }
        if (digits.length == 10) digits = "91$digits"
        if (digits.length == 11 && digits.startsWith("0")) digits = "91" + digits.drop(1)

        val url = if (message.isBlank()) "https://wa.me/$digits"
        else "https://wa.me/$digits?text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.whatsapp")
        val ok = launch(intent) || launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        if (!ok) return CommandResult("WhatsApp nahi khul paya.")
        return if (message.isBlank()) CommandResult("${contact.first} ki chat khol di.")
        else CommandResult("${contact.first} ke liye message ready hai. Check karke Send dabaiye.")
    }

    private fun youtube(q: String): CommandResult {
        if (q.isBlank()) {
            val i = ctx.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))
            return launchResult(i, "YouTube khol raha hoon.")
        }
        val search = Intent(Intent.ACTION_SEARCH)
            .setPackage("com.google.android.youtube")
            .putExtra(SearchManager.QUERY, q)
        if (launch(search)) return CommandResult("YouTube par $q dhoondh raha hoon.")
        val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
        return launchResult(web, "YouTube par $q dhoondh raha hoon.")
    }

    // ---------------------------------------------------------------- accessibility

    private fun accessibilityMissing() = CommandResult(
        "Iske liye pehle Accessibility on karna hoga, boss. App me doosra button dabaiye."
    )

    private fun global(action: Int, reply: String): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return accessibilityMissing()
        return CommandResult(reply, background = true) { s.performGlobalAction(action) }
    }

    private fun gesture(fingerUp: Boolean, reply: String): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return accessibilityMissing()
        return CommandResult(reply, background = true) { s.swipe(fingerUp) }
    }

    private fun click(target: String): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return accessibilityMissing()
        return CommandResult("$target dabaa raha hoon.", background = true) {
            if (!s.clickText(target)) toast("'$target' screen par nahi mila")
        }
    }

    private fun type(text: String): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return accessibilityMissing()
        return CommandResult("Likh raha hoon.", background = true) {
            if (!s.typeText(text)) toast("Koi text box nahi mila")
        }
    }
}
