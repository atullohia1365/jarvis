# JARVIS v1 – Atul ka personal voice assistant (Android)

Moto Edge 70 Fusion (Android 16) ke liye bana hai, lekin Android 10+ wale kisi bhi phone par chalega.

## APK kaise banaye (2 tareeke)

### Tareeka A: GitHub se (laptop par kuch install nahi karna)
1. github.com par naya **private** repo banao, naam `jarvis`.
2. Is folder me terminal kholo aur chalao:
   ```
   git init
   git add .
   git commit -m "JARVIS v1"
   git branch -M main
   git remote add origin https://github.com/<aapka-username>/jarvis.git
   git push -u origin main
   ```
3. Repo me **Actions** tab kholo. "Build JARVIS APK" 4–6 minute me green ✅ ho jayega.
4. Us run par click karo, neeche **Artifacts → JARVIS-apk** download karo. Zip ke andar `app-debug.apk` hai.

### Tareeka B: Android Studio se
1. Android Studio me **Open** dabake ye `Jarvis` folder kholo.
2. Gradle sync hone do.
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk`

## Phone par install aur setup
1. APK phone me bhejo aur install karo ("Install unknown apps" allow karna padega).
2. JARVIS kholo, phir **1. Permissions do** dabao aur sab Allow karo.
3. **Accessibility unlock (Android 13+ ke liye zaroori):**
   - Pehle **2. Accessibility on karo** dabao. "JARVIS screen control" greyed/blocked dikhega.
   - Ab **3. App info** dabao, upar right ⋮ menu → **Allow restricted settings**.
   - Wapas Accessibility me jaake **JARVIS screen control** ON karo.
4. App info → Battery → **Unrestricted** karo.
5. Notification panel kholo → edit (pencil) → **JARVIS** tile ko upar drag karo.
6. Offline sunne ke liye: Settings → Google → Voice / Speech → Offline speech recognition → **English (India)** download karo.

## Use kaise karein
- App me bada **BOLO** button dabao, ya kahin se bhi **notification panel → JARVIS tile** dabao.
- Hinglish me bolo:

| Bolo | Kya hoga |
|---|---|
| torch on karo / torch band karo | Flashlight |
| battery kitni hai | Battery % |
| time kya hai / aaj ki date | Time / date |
| alarm 6 baje / alarm 9:30 raat | Alarm set |
| volume badhao / volume kam / volume full | Volume |
| silent karo / normal mode | Ringer |
| youtube kholo / instagram kholo / yt studio kholo | App kholna |
| youtube par shiv bhajan | YouTube search |
| search weather mohali | Google search |
| mummy ko call karo | Contact ko call |
| rahul ko whatsapp karo ki main late aaunga | WhatsApp message ready (Send aap dabaoge) |
| wifi / bluetooth | Settings panel |
| scroll down / scroll up / back / home / recent | Screen control |
| screenshot / lock karo | Screenshot / lock |
| subscribe par click karo / click like | Screen par us naam ke button par click |
| type hello bhai | Text box me likhna |

## Dhyan rakhne wali baatein
- Contacts English naam se save hone chahiye (jaise "Mummy"), tabhi awaaz se match honge.
- WhatsApp message apne aap send nahi hota. Galat contact ko message na chala jaye, isliye Send aap dabate ho.
- Accessibility se JARVIS screen dekh sakta hai. Ye data kahin nahi bhejta, sab phone par hi hota hai.

## Next version (v2) me kya aayega
- "Jarvis" bolke jagana (wake word, Picovoice Porcupine)
- Phone par chalne wala AI (Gemma), taaki free-form baat samjhe
- Jarvis jaisi British awaaz (Piper TTS)
